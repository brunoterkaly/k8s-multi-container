docker build . -t brunoterkaly/py-red
docker push brunoterkaly/py-red

