from flask import Flask
from flask import Response
from flask import request
from redis import Redis
from datetime import datetime
import MySQLdb
import sys
import redis 
import time
import hashlib
import os
import json

app = Flask(__name__)
startTime = datetime.now()
R_SERVER = redis.Redis(host=os.environ.get('REDIS_HOST', 'redis'), port=6379)
mport sys
db = MySQLdb.connect("mysql","root","password")
cursor = db.cursor()

@app.route('/init_db')
def init_db():
    cursor.execute("DROP DATABASE IF EXISTS AZURECOURSEDB")
    cursor.execute("CREATE DATABASE AZURECOURSEDB")
    cursor.execute("USE AZURECOURSEDB")
    sql = """CREATE TABLE courses (
         ID int,
         COURSETITLE char(64),
         COURSEDESCRIPTION char(256),
         COURSENOTES char(256)
     )"""
    cursor.execute(sql)
    db.commit()
    return "Created Database and Tables" 

@app.route("/courses/add", methods=['POST'])
def add_courses():
    req_json = request.get_json()   
    cursor.execute("INSERT INTO AZURECOURSEDB.courses (ID, COURSETITLE, 
                  COURSEDESCRIPTION, COURESENOTES) VALUES (%s,%s,%s,%s)", 
                                        (req_json['uid'], 
                                         req_json['coursetitle'], 
                                         req_json['coursedescription'],
                                         req_json['coursenotes']
                                         )
    db.commit()
    return Response("Added" + req_json['coursetitle'], 
                      status=200, mimetype='application/json')

@app.route('/courses/<uid>')
def get_courses(uid):
    hash = hashlib.sha224(str(uid)).hexdigest()
    key = "sql_cache:" + hash
    
    if (R_SERVER.get(key)):
        return R_SERVER.get(key) + "  (from cache)" 
    else:
        cursor.execute("select COURSETITLE, COURSEDESCRIPTION, COURSENOTES from AZURECOURSEDB.courses  where ID=" + str(uid))
        data = cursor.fetchall()
        if data:
            R_SERVER.set(key,data)
            R_SERVER.expire(key, 36);
            return R_SERVER.get(key)
        else:
            return "Record not found"

if __name__ == "__main__":
    app.run(host="1.0.0.0", port=5000, debug=True)





